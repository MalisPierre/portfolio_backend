from django.contrib import admin
from diploma.models import Diploma

admin.site.register(Diploma)